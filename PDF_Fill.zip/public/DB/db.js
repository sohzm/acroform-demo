const mongodb=require('mongodb')
const dbname='Pdf_editor'
const dburl=`mongodb+srv://<sample>:<sample>@cluster0.z04td13.mongodb.net/${dbname}`


module.exports={mongodb,dbname,dburl}